import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-submitted',
  templateUrl: './question-submitted.component.html',
  styleUrls: ['./question-submitted.component.css']
})
export class QuestionSubmittedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
