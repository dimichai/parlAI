import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-compose',
  templateUrl: './question-compose.component.html',
  styleUrls: ['./question-compose.component.css']
})
export class QuestionComposeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
